*** DESCRIPTION ***

Theme for Windows 10. Supported versions: 1903, 1909, 2004 and 2009(20H2).
To determine the version, run 'winver' from the start menu.


*** HOW TO ***

1.Create a system restore point!!! In case your system gets messed up you can restore it.

2.Patch your system using ultraUXThemePatcher:
https://mhoefs.eu/software_uxtheme.php?lang=en
See FAQ on patcher site if patcher is not working.
OR
You may use: 
https://github.com/namazso/SecureUxTheme

3.Open the Theme folder.

The "No address bar" folder contains themes in which the address bar is hidden.
The "Normal" folder contains the regular themes.
The "Office app colors not affected" contains themes which do not affect the office app colors.

Open the desired folder and copy its contents to C:\Windows\Resources\Themes.


4.Open Settings > Personalization > Themes. Apply theme.

***WALLPAPERS***
https://www.dropbox.com/sh/wxb4k4dubf584p1/AADCCbds3qfKFSkG4LEOD39za?dl=0


*** TWEAKS ***

Install OldNewExplorer to remove the ribbon.
https://msfn.org/board/topic/170375-oldnewexplorer-118/
See image 01 for configuration

Install Blank it for a cleaner address bar
http://fav.me/dbnc5q5

Apply other tweaks using Winaero Tweaker
https://winaero.com/

Use Alt + Shift + P and Alt + P to toggle the details pane and preview pane respectively

Time and Date
https://github.com/White-Tiger/T-Clock


*** NOTE ***

If the some of the above instructions don't make sense, check out Youtube for videos on installing custom themes on Windows 10.
Below are links to some useful guides.
https://www.deviantart.com/niivu/art/Guide-To-Installing-Windows-10-Themes-708835586
https://www.deviantart.com/dpcdpc11/journal/HOW-TO-INSTALL-AND-USE-WINDOWS-THEMES-GUIDE-861400195

Apply the  default Windows theme and uninstall patcher before updating to major Windows 10 update e.g updating from 1909 to 2004


***Support***

If you like the theme you may support me by buying it here:
https://gum.co/darkwin10

Thanks, enjoy!