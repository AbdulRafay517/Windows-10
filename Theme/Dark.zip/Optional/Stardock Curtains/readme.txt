DESCRIPTION
Curtains Styles to add dark theme title bar and caption buttons on modern Windows apps.

HOW TO
1. Install Stardock's Curtains app: https://www.stardock.com/products/curtains/
2. Double click on each Curtains Style that you want to install. The Curtains Styles panel will be opened.
3. Click the desired Curtain Style to apply it.
4. For better compatibility, go to Curtains Options > More style settings... and uncheck "Apply style to window title bars"

Credit:
dpcdpc11.deviantart.com/